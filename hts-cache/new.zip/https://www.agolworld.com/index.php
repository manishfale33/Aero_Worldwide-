
<!doctype html>
<html lang="zxx">
<head>
<!-- Google Tag Manager -->
<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
})(window,document,'script','dataLayer','GTM-WWK3467');</script>
<!-- End Google Tag Manager -->
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<title>AGOL WORLD - Specialized in Time Critical Shipments</title>
<!-- Favicon -->
    <link rel="apple-touch-icon" href="assets/img/favicon.png" />
    <link rel="shortcut icon" type="image/x-icon" href="assets/img/favicon.png" />

       
     <!-- Bootstrap  v5.1.3 css -->
    <link rel="stylesheet" href="assets/css2/bootstrap.min.css" />
    <!-- Meanmenu  css -->
    <link rel="stylesheet" href="assets/css2/meanmenu.css" />
    <!-- Sal css -->
    <link rel="stylesheet" href="assets/css2/sal.css" />
    <!-- Magnific css -->
    <link rel="stylesheet" href="assets/css2/magnific-popup.css" />
    <!-- Swiper Slider css -->
    <link rel="stylesheet" href="assets/css2/swiper.min.css" />
    <!-- Carousel css file -->
    <link rel="stylesheet" href="assets/css2/owl.carousel.css" />
    <!-- Icons css -->
    <link rel="stylesheet" href="assets/css2/icons.css" />
    <!-- Odometer css -->
    <link rel="stylesheet" href="assets/css2/odometer.min.css" />
    <!-- Select css -->
    <link rel="stylesheet" href="assets/css2/nice-select.css" />
    <!-- Animate css -->
    <link rel="stylesheet" href="assets/css2/animate.css" />
    <!-- Style css -->
    <link rel="stylesheet" href="assets/css2/style.css" />
    <!-- Responsive css -->
    <link rel="stylesheet" href="assets/css2/responsive.css" />


<meta name="description" content="AGOL World - if you are running out of time, and have critical deliveries to be made? You may call or email - We are available 24*7. Get Quote in less than 15 minutes!" />
<link rel="canonical" href="https://www.agolworld.com" />
 <meta name="keywords" content="Time Critical Shipments, AGOL Worldwide, AGOL Worldwide USA, AGOL Worldwide India, AGOL Worldwide UK, AGOL Worldwide Germany, AGOL Worldwide China">
<meta name="google-site-verification" content="bYPjDNhKciLAeyyjkq_x7d89SSEzQSRNheaTzNRqCZE" />
<style>
.shipment-content {
    text-align: center;
    max-width: 1200px;
    margin: auto;
}
</style>
<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=G-7RSB8ZVFFZ"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'G-7RSB8ZVFFZ');
</script>
</head>
<body>
<!-- Google Tag Manager (noscript) -->
<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-WWK3467"
height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
<!-- End Google Tag Manager (noscript) -->
<!--<div class="preloader">
<div class="lds-ripple">
<div></div>
<div></div>
</div>
</div>-->

 <!-- Preloader start -->
    <div id="preloader" class="preloader">
        <div class="animation-preloader">
            <div class="spinner">
                <div class="loader-icon">
                    <img src="assets/img/logo.png" alt="Agol World" />
                </div>
            </div>
            <div class="txt-loading">
                <span data-text-preloader="A" class="letters-loading">A</span>
                <span data-text-preloader="G" class="letters-loading">G</span>
                <span data-text-preloader="O" class="letters-loading">O</span>
                <span data-text-preloader="L" class="letters-loading">L</span>
                <span data-text-preloader="W" class="letters-loading">W</span>
                <span data-text-preloader="O" class="letters-loading">O</span>
                <span data-text-preloader="R" class="letters-loading">R</span>
                <span data-text-preloader="L" class="letters-loading">L</span>
                <span data-text-preloader="D" class="letters-loading">D</span>
                <!--span data-text-preloader="W" class="letters-loading">W</span>
                <span data-text-preloader="I" class="letters-loading">I</span>
                <span data-text-preloader="D" class="letters-loading">D</span>
                <span data-text-preloader="E" class="letters-loading">E</span-->

            </div>
        </div>
        <button class="tj-primary-btn">Cancel Preloader</button>
    </div>
    <!-- Preloader end -->
<!-- Offcanvas Area Start-->
    <div id="tj-overlay-bg2" class="tj-overlay-canvas"></div>
    <div class="tj-offcanvas-area">
        <div class="tj-offcanvas-header d-flex align-items-center justify-content-between">
            <div class="logo-area text-center">
                <a href="index.php"><img src="assets/img/logo.png" alt="Logo" /></a>
            </div>
            <div class="offcanvas-icon">
                <a id="canva_close" href="#">
                    <i class="fa-light fa-xmark"></i>
                </a>
            </div>
        </div>
        <!-- Canvas Mobile Menu start -->
        <nav class="right_menu_togle mobile-navbar-menu d-lg-none" id="mobile-navbar-menu"></nav>
        <p class="des d-none d-lg-block">

        </p>
        <!-- Canvas Menu end -->
        <div class="contact-info-list">
            <h4 class="offcanvas-title">Contact info</h4>
            <div class="contact-box contact-box1">
                <div class="contact-icon">
                 <i class="fa-solid fa-envelope"></i>
                </div>
                <div class="contact-link">
                    <span class="d-block"> Email us:</span>
                    <a href="time.critical@agolworld.com"> time.critical@agolworld.com</a>
                </div>
            </div>
            <div class="contact-box">
                <div class="contact-icon">
                    <i class="flaticon-telephone"></i>
                </div>
                <div class="contact-link">
                    <span class="d-block"> Call us:</span>
                    <i class="flaticon flaticon-call"></i><a href="tel:+12523043851">+12523043851
                    </a>
                </div>
            </div>
            <div class="contact-box">
                <div class="contact-icon">
                    <i class="flaticon-telephone"></i>
                </div>
                <div class="contact-link">
                    <span class="d-block"> Call us:</span>
                    <i class="flaticon flaticon-call"></i><a href="tel:+442034753632">+442034753632
                    </a>
                </div>
            </div>
            <!--div class="contact-box">
                <div class="contact-icon">
                    <i class="flaticon-telephone"></i>
                </div>
                <div class="contact-link">
                    <span class="d-block"> Call us:</span>
                    <i class="flaticon flaticon-call"></i><a href="tel: +4980316194976"> +4980316194976
                    </a>
                </div>
            </div-->
            <div class="contact-box">
                <div class="contact-icon">
                    <i class="flaticon-telephone"></i>
                </div>
                <div class="contact-link">
                    <span class="d-block"> Call us:</span>
                    <i class="flaticon flaticon-call"></i><a href="tel: +919730702811"> +919730702811
                    </a>
                </div>
            </div>
        </div>
        <div class="tj-theme-button tj-btn d-lg-none">
            <a class="tj-primary-btn" href="#"> Track Order <i class="flaticon-right-1"></i> </a>
        </div>
    </div>
    <!-- Offcanvas Area End-->

    <!-- start: Search Popup -->
    <section class="search_popup">
        <div class="container">
            <div class="row">
                <div class="col-xxl-12">
                    <div class="search_wrapper">
                        <div class="search_top d-flex justify-content-between align-items-center">
                            <div class="search_logo">
                                <a href="index.php">
                                    <img src="assets/img/logo.png" alt="logo" />
                                </a>
                            </div>
                            <div class="search_close">
                                <a class="search_close_btn" href="#"> <i class="fa-regular fa-xmark"></i></a>
                            </div>
                        </div>
                        <div class="search_form">
                            <form action="#">
                                <div class="search_input">
                                    <input class="search-input-field" type="text"
                                        placeholder="Type here to search..." />
                                    <span class="search-focus-border"></span>
                                    <a href="#"> <i class="flaticon-loupe"></i></a>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <div class="search-popup-overlay"></div>
    <!-- end: Search Popup -->

  <header class="header-section-two" id="header-sticky">
        <div class="header-topbar d-none d-lg-block">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="topbar-content-area">
                            <div class="header-content-left">
                                <ul class="list-gap">
                                    <li>
                                       <i class="fa-solid fa-envelope"></i><a
                                            href="mailto:time.critical@agolworld.com"> time.critical@agolworld.com</a>
                                    </li><a style="color: white;">24*7 Customer Service</a>&nbsp;
                                    <li>
                                        <i class="flaticon flaticon-call"></i><a href="tel:+12523043851">+12523043851
                                        </a>
                                    </li>
                                    <li>
                                        <i class="flaticon flaticon-call"></i><a href="tel:+442034753632">+442034753632
                                        </a>
                                    </li>
                                    <!--li>
                                        <i class="flaticon flaticon-call"></i><a href="tel: +4980316194976">
                                            +4980316194976
                                        </a>
                                    </li-->
                                </ul>
                            </div>
                            <div class="header-content-right d-flex align-items-center justify-content-end">
                                <div class="input-form tj-select">
                                    <a>
                                        <div class="single-footer-widget">
                                            <!-- Container for the custom translation bar -->
                                            <div id="custom_translate_element"></div>
                                        </div>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- header menu Start -->
        <div class="tj-header-menu-bottom">
            <div class="container">
                <div class="row align-items-center">
                    <div class="col-lg-12">
                        <div class="header-menu-area">
                            <!-- Logo Section Start -->
                            <div class="logo-box">
                                <a href="index"><img src="assets/img/logo.png" alt="Logo" /></a>
                            </div>
                            <!-- Logo Section End -->

                            <!-- Mainmenu Item Start -->
                            <div class="tj-main-menu d-lg-block d-none text-end" id="main-menu">
                                <ul class="main-menu">
                                    <li class="">
                                        <a class="" href="index"> Home</a>
                                    </li>
                                    <li class="">
                                        <a href="about_us"> About Us</a>
                                    </li>
                                    <li class="menu-item-has-children">
                                        <a href="service"> Services</a>
                                        <ul class="list-gap sub-menu-list">
                                            <li><a href="importer-of-record-services">Importer On Record</a></li>
                                            <li><a href="on-board-courier-services">On Board Courier</a></li>
                                            <li><a href="dedicated-ground-services">Dedicated Ground</a></li>
                                            <li><a href="next-flight-out-services">Next Flights Out</a></li>
                                            <li><a href="air-charters-services">Air Charters</a></li>
                                        </ul>
                                    </li>
                                    <li class="">
                                        <a href="industries">Industries</a>
                                    </li>
                                    <li class="">
                                        <a href="blog"> Blog</a>
                                    </li>
                                    <li class=""><a href="contact_us">Contact</a></li>
                                </ul>
                            </div>
                            <!-- Mainmenu Item End -->

                            <div class="menu-search-box d-flex align-items-center">
                                <div class="header_searce d-none d-lg-block">
                                    <button class="search-btn"><i class="flaticon-loupe"></i></button>
                                </div>
                                <div class="hambugar-icon d-none d-lg-block">
                                    <a class="canva_expander" href="#">
                                        <i class="flaticon-menu"></i>
                                    </a>
                                </div>
                                <div class="">
                                    <a>
                                        <div class="single-footer-widget">
                                            <!-- Container for the custom translation bar -->
                                            <div id="custom_translate_element"></div>
                                        </div>
                                    </a>
                                </div>
                                <div class="tj-hambagur-icon d-lg-none">
                                    <a class="canva_expander nav-menu-link menu-button" href="#">
                                        <span class="dot1"></span>
                                        <span class="dot2"></span>
                                        <span class="dot3"></span>
                                    </a>
                                </div>
                                <div class="tj-theme-button tj-btn text-end d-none d-lg-block">
                                    <a class="tj-primary-btn" href="contact.html">
                                        Track Order <i class="flaticon-right-1"></i>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- Header end End -->
                </div>
            </div>
        </div>

        <!-- header menu Start -->
    </header>
    
     <script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>

    <script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>

    <!-- Google Translate API script -->
    <script type="text/javascript"
        src="//translate.google.com/translate_a/element.js?cb=googleTranslateElementInit"></script>

    <!-- Google Translate API initialization script -->
   <script type="text/javascript">
 function googleTranslateElementInit() {
    new google.translate.TranslateElement({
        pageLanguage: 'en',
        includedLanguages: 'en,af,sq,am,ar,hy,az,eu,be,bn,bs,bg,ca,ceb,ny,zh-CN,zh-TW,co,hr,cs,da,nl,en,eo,et,tl,fi,fr,fy,gl,ka,de,el,gu,ht,ha,haw,iw,hmn,hu,is,ig,id,ga,it,ja,jw,kn,kk,km,ko,kk,ku,ky,lo,la,lv,lt,lb,mk,mg,ms,ml,mt,mi,mr,mn,my,ne,no,or,ps,fa,pl,pt,pa,ro,ru,sm,gd,sr,st,sn,sd,si,sk,sl,so,es,su,sw,sv,tg,ta,tt,te,th,tr,tk,uk,ur,ug,uz,vi,cy,xh,yi,yo,zu',
        layout: google.translate.TranslateElement.InlineLayout.SIMPLE,
        autoDisplay: false
    }, 'custom_translate_element');
}


    // Trigger the initialization script
    $(document).ready(function () {
        googleTranslateElementInit();
    });
</script>


    <!--=========== Hero Section Start =========-->
    <section class="tj-hero-section">
        <div class="hero-bg-1"></div>
        <div class="hero-bg-2"></div>
        <div class="container">
            <div class="hero-shape pulse">
                <img src="assets/img2/banner/banner-shape2.png" alt="Shape" />
            </div>
            <div class="row">
                <div class="col-xl-6 col-lg-12"></div>
                <div class="col-xl-6 col-lg-12">
                    <div class="tj-hero-content">
                        <div class="tj-section-heading">
                            <span class="sub-title active-shape2">Accelerate your shipment with AGOL WORLD OBC! </span>
                            <h1 class="title">The optimal choice for time-sensitive Shipments</h1>
                        </div>
                        <div class="tj-theme-button">
                            <a class="tj-transparent-btn" href="contact.html">
                                Read More <i class="flaticon-right-1"></i>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--=========== Hero Section End =========-->

    <!--=========== Service Section Start =========-->
    <section class="tj-service-section-two">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="tj-service-icon-box2">
                        <ul class="list-gap">
                            <li>
                                <div class="service-item">
                                    <div class="tj-service-icon">
                                        <div class="service-icon">
                                            <i class="fa-light fa-memo-circle-check"></i>
                                        </div>
                                        <div class="sub-title">
                                            <span>Importer On Record </span>
                                        </div>
                                    </div>
                                    <div class="service-arrow">
                                        <a href="service"> <i class="fa-light fa-arrow-right"></i></a>
                                    </div>
                                </div>
                            </li>
                            <li>
                                <div class="service-item">
                                    <div class="tj-service-icon">
                                        <div class="service-icon">
                                            <i class="flaticon-pick"></i>
                                        </div>
                                        <div class="sub-title">
                                            <span>On Board Courier</span>
                                        </div>
                                    </div>
                                    <div class="service-arrow">
                                        <a href="service"> <i class="fa-light fa-arrow-right"></i></a>
                                    </div>
                                </div>
                            </li>
                            <li>
                                <div class="service-item nth-child-3">
                                    <div class="tj-service-icon">
                                        <div class="service-icon">
                                            <i class="flaticon-delivery-van"></i>
                                        </div>
                                        <div class="sub-title">
                                            <span>Dedicated Ground</span>
                                        </div>
                                    </div>
                                    <div class="service-arrow">
                                        <a href="service"> <i class="fa-light fa-arrow-right"></i></a>
                                    </div>
                                </div>
                            </li>
                            <li>
                                <div class="service-item">
                                    <div class="tj-service-icon">
                                        <div class="service-icon">
                                            <i class="flaticon-air-freight"></i>
                                        </div>
                                        <div class="sub-title">
                                            <span>Next Flights Out</span>
                                        </div>
                                    </div>
                                    <div class="service-arrow">
                                        <a href="service"> <i class="fa-light fa-arrow-right"></i></a>
                                    </div>
                                </div>
                            </li>
                            <li>
                                <div class="service-item nth-child-4">
                                    <div class="tj-service-icon">
                                        <div class="service-icon">
                                            <i class="fa-light fa-plane-departure"></i>
                                        </div>
                                        <div class="sub-title">
                                            <span>Air Charters</span>
                                        </div>
                                    </div>
                                    <div class="service-arrow">
                                        <a href="service"> <i class="fa-light fa-arrow-right"></i></a>
                                    </div>
                                </div>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--=========== Service Section End =========-->

    <!--=========== About Section Start =========-->
    <section class="tj-about-section-two">
        <div class="container">
            <div class="row">
                <div class="col-lg-6" data-sal="slide-left" data-sal-duration="800">
                    <div class="about-group-image2 d-flex flex-wrap align-items-start flex-column">
                        <div class="image-box">
                            <img class="p-z-idex" src="assets/img2/about/ab-3.jpg" alt="Image" />
                        </div>
                        <img class="group-1 p-z-idex" src="assets/img2/about/ab-4.jpg" alt="Image" />
                        <img class="group-shape" src="assets/img2/about/ab-shape.png" alt="Image" />
                    </div>
                </div>
                <div class="col-lg-6" data-sal="slide-right" data-sal-duration="800">
                    <div class="about-content-two">
                        <div class="tj-section-heading">
                            <!--span class="sub-title active-shape"> See Sea Transport Benifit</span-->
                            <h2 class="title">Simply Delivered!</h2>
                            <p class="desc">
                                  AGOL WORLD is an international logistics company and a tenacious industry player. AGOL WORLD, an Indian-based company, is the brainchild of a group of young, talented logisticians and entrepreneurs with years of experience in the industry, creating a new generation of logistics.
                            </p>
                            <ul class="list-gap">
                                <li>
                                    <i class="flaticon-right-chevron-1"></i>
                                    24/7 Business Support
                                </li>
                                <li>
                                    <i class="flaticon-right-chevron-1"></i>
                                    Secure Transportation
                                </li>
                                <li>
                                    <i class="flaticon-right-chevron-1"></i>
                                    Easy And Quick Problem Analysis
                                </li>
                                <li>
                                    <i class="flaticon-right-chevron-1"></i>
                                    World Wide Most Effective Business
                                </li>
                            </ul>
                        </div>
                        <div class="content-box d-flex align-items-center">
                            <div class="tj-icon-box">
                                <div class="ab-text d-flex align-items-center">
                                    <div class="ab-icon">
                                        <img src="assets/img2/icon/global.svg" alt="Icon" />
                                    </div>
                                    <div class="ab-title">
                                        <h5 class="title">Our Mission</h5>
                                    </div>
                                </div>
                                <p class="desc">Always listen to and understand our stakeholders; offer best-in-class transportation solutions; use technology to gain and facilitate efficiency and visibility; and build long-term growth through organic relationship development.</p>
                            </div>
                            <div class="tj-icon-box">
                                <div class="ab-text d-flex align-items-center">
                                    <div class="ab-icon">
                                        <img src="assets/img2/icon/winner.svg" alt="Icon" />
                                    </div>
                                    <div class="ab-title">
                                        <h5 class="title">Our Vision</h5>
                                    </div>
                                </div>
                                <p class="desc">To be an ever-lasting, innovative, time-critical logistics company that enables customers to safeguard their unplanned big losses and achieve their mission through our team of trusted, empowered, and respected professionals.</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--=========== About Section End =========-->

    <!--=========== Cta Section Start =========-->
    <section class="tj-cta-section-two">
        <div class="tj_cta_image"></div>
        <div class="tj_cta_image1"></div>
        <div class="container">
            <div class="row">
                <div class="col-lg-6 col-md-6">
                    <div class="tj-cta-content">
                        <div class="tj-section-heading">
                            <span class="sub-title active-shape2"> Support Center 24/7</span>
                            <h4 class="title">Feel free to contact us for additional information.</h4>
                        </div>
                        <div class="tj-theme-button">
                            <a class="tj-transparent-btn" href="contact_us">
                                Read More <i class="flaticon-right-1"></i>
                            </a>
                        </div>
                    </div>
                </div>
                <div class="col-lg-6 col-md-6">
                    <div class="tj-cta-content tj-cta-content2">
                        <div class="tj-section-heading">
                            <span class="sub-title active-shape2"> Here We Are</span>
                            <h4 class="title">Get a quote from AGOL WORLD.</h4>
                        </div>
                        <div class="tj-theme-button">
                            <a class="tj-transparent-btn" href="contact_us">
                                Get a Quote <i class="flaticon-right-1"></i>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--=========== Cta Section End =========-->

    <!--=========== Service Section Start =========-->
    <section class="tj-service-section-three">
        <div class="container">
            <div class="row">
                <div class="tj-section-heading text-center">
                    <span class="sub-title active-shape"> What We Do</span>
                    <h2 class="title">Logistics</h2>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-6" data-sal="slide-up" data-sal-duration="800" data-sal-delay="300">
                    <div class="service-item-two d-flex justify-content-between">
                        <div class="service-image">
                            <img src="assets/img2/service/service-3.jpg" alt="Service" />
                        </div>
                        <div class="service-text">
                            <div class="services-icon">
                                <i class="fa-light fa-memo-circle-check"></i>
                            </div>
                            <h4 class="service-title"><a href="">Importer On Record<span style="visibility: hidden;">--</span></a></h4>
                            <!--p class="des">
                                Long established fact that reader will be distracted by the Long established fact
                                that will be distracted by the Long
                            </p-->
                            <div class="tj-theme-button">
                                <a class="tj-transparent-btn-two" href="importer-of-record-services">Read More <i
                                        class="flaticon-right-1"></i></a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-6" data-sal="slide-up" data-sal-duration="800" data-sal-delay="400">
                    <div class="service-item-two d-flex justify-content-between">
                        <div class="service-image">
                            <img src="assets/img2/service/service-19.jpg" alt="Service" />
                        </div>
                        <div class="service-text">
                            <div class="services-icon">
                                <i class="flaticon-pick"></i>
                            </div>
                            <h4 class="service-title"><a href="">On Board Courier<span style="visibility: hidden;">----</span></a></h4>
                            <!--p class="des">
                                Long established fact that reader will be distracted by the Long established fact
                                that will be distracted by the Long
                            </p-->
                            <div class="tj-theme-button">
                                <a class="tj-transparent-btn-two" href="on-board-courier-services">Read More <i
                                        class="flaticon-right-1"></i></a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-6" data-sal="slide-up" data-sal-duration="800" data-sal-delay="500">
                    <div class="service-item-two d-flex justify-content-between">
                        <div class="service-image">
                            <img src="assets/img2/service/service-10.jpg" alt="Service" />
                        </div>
                        <div class="service-text">
                            <div class="services-icon">
                                <i class="flaticon-delivery-van"></i>
                            </div>
                            <h4 class="service-title"><a href="">Dedicated Ground<span style="visibility: hidden;">---</span></a></h4>
                            <!--p class="des">
                                Long established fact that reader will be distracted by the Long established fact
                                that will be distracted by the Long
                            </p-->
                            <div class="tj-theme-button">
                                <a class="tj-transparent-btn-two" href="dedicated-ground-services">Read More <i
                                        class="flaticon-right-1"></i></a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-6" data-sal="slide-up" data-sal-duration="800" data-sal-delay="600">
                    <div class="service-item-two d-flex justify-content-between">
                        <div class="service-image">
                            <img src="assets/img2/service/service-4.jpg" alt="Service" />
                        </div>
                        <div class="service-text">
                            <div class="services-icon">
                                <i class="flaticon-plane"></i>
                            </div>
                            <h4 class="service-title"><a href="">Next Flights Out<span style="visibility: hidden;">-----</span></a></h4>
                            <!--p class="des">
                                Long established fact that reader will be distracted by the Long established fact
                                that will be distracted by the Long
                            </p-->
                            <div class="tj-theme-button">
                                <a class="tj-transparent-btn-two" href="next-flight-out-services">Read More <i
                                        class="flaticon-right-1"></i></a>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-lg-6" data-sal="slide-up" data-sal-duration="800" data-sal-delay="600">
                    <div class="service-item-two d-flex justify-content-between">
                        <div class="service-image">
                            <img src="assets/img2/service/service-8.jpg" alt="Service" />
                        </div>
                        <div class="service-text">
                            <div class="services-icon">
                                <i class="fa-light fa-plane-departure"></i>
                            </div>
                            <h4 class="service-title"><a href="">Air Charters<span style="visibility: hidden;">--------</span></a></h4>
                            <!--p class="des">
                                Long established fact that reader will be distracted by the Long established fact
                                that will be distracted by the Long
                            </p-->
                            <div class="tj-theme-button">
                                <a class="tj-transparent-btn-two" href="air-charters-services">Read More <i
                                        class="flaticon-right-1"></i></a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--=========== Service Section End =========-->

    <!--=========== Contact Section Start =========-->
    <section class="tj-tabs-section">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="tabs-box">
                        <ul class="nav nav-pills" id="pills-tab" role="tablist">
                            <li class="nav-item" role="presentation">
                                <button class="nav-link active" id="pills-home-tab" data-bs-toggle="pill"
                                    data-bs-target="#pills-home" type="button" role="tab" aria-controls="pills-home"
                                    aria-selected="true">
                                    <i class="flaticon-box"></i> Request A Quote
                                </button>
                            </li>
                            <li class="nav-item" role="presentation">
                                <button class="nav-link" id="pills-profile-tab" data-bs-toggle="pill"
                                    data-bs-target="#pills-profile" type="button" role="tab"
                                    aria-controls="pills-profile" aria-selected="false">
                                    <i class="flaticon-tracking"></i> Track & Trace
                                </button>
                            </li>
                        </ul>
                    
                        <div class="tab-content" id="pills-tabContent">
                            <div class="tab-pane fade show active" id="pills-home" role="tabpanel"
                                aria-labelledby="pills-home-tab">
                                <div class="row">
                                   <form method="POST" action="index.php" onsubmit="return validateForm()">
    <div class="col-lg-8">
        <div class="tabs-form-box">
            <h6 class="title">Personal Data</h6>
            <div class="row">
                <div class="col-md-4">
                    <div class="tabs-input">
                        <input type="text" id="nameOne" name="R_Name" placeholder="Name*" required />
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="tabs-input">
                        <input type="email" id="emailThree" name="R_Email" placeholder="Mail*" required />
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="tabs-input">
                        <input type="number" id="emailTwo" name="R_Contactno" placeholder="Phone*" required />
                    </div>
                </div>
            </div>
        </div>
        <div class="tabs-form-box">
            <h6 class="title">Shipment Data</h6>
            <div class="row">
                <div class="col-md-4">
                    <div class="tabs-input">
                        <input type="text" id="freightOne" name="R_Freight" placeholder="Freight Type" required />
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="tabs-input">
                        <input type="text" id="departureOne" name="R_City_Dep" placeholder="City of Departure" required />
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="tabs-input">
                        <input type="text" id="deliveryOne" name="R_Delivery_City" placeholder="Delivery City" required />
                    </div>
                </div>
            </div>
        </div>
        <div class="tabs-form-box">
            <div class="row">
                <div class="col-md-4">
                    <div class="tabs-input">
                        <input type="number" id="incotermsOne" name="R_Incoterms" placeholder="Incoterms" required />
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="row">
                        <div class="col-md-6">
                            <div class="tabs-input">
                                <input type="number" id="weightOne" name="R_Weight" placeholder="Weight" required />
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="tabs-input">
                                <input type="number" id="heightOne" name="R_Height" placeholder="Height" required />
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="row">
                        <div class="col-md-6">
                            <div class="tabs-input">
                                <input type="number" id="width" name="R_Width" placeholder="Width" required />
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="tabs-input">
                                <input type="number" id="lengthOne" name="R_Length" placeholder="length" required />
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
       
        <div class="tj-theme-button">
            <button class="tj-primary-btn tabs-button" type="submit" value="submit" name="submit">
                Request For A Quote <i class="flaticon-right-1"></i>
            </button>
        </div>
    </div>
</form>       
                            
                                    <div class="col-lg-4">
                                        <div class="tabs-image">
                                            <img src="assets/img2/project/tabs-1.jpg" alt="Image" />
                                        </div>
                                    </div>
                                </div>
                            </div>
                        
                            <div class="tab-pane fade" id="pills-profile" role="tabpanel"
                                aria-labelledby="pills-profile-tab">
                                <div class="row">
                                    <form method="POST" action="index">
                                    <div class="col-lg-8">
                                        <div class="tabs-form-box">
                                            <h6 class="title">Reference No</h6>
                                            <div class="row">
                                                <div class="col-md-4">
                                                    <div class="tabs-input">
                                                        <input type="number" id="No" name="R_No" placeholder="Reference No*"
                                                            required />
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                         <div class="tabs-form-box">
                                            <h6 class="title">Name</h6>
                                            <div class="row">
                                                <div class="col-md-4">
                                                    <div class="tabs-input">
                                                        <input type="text" id="Name" name="R_Name"
                                                            placeholder="Name" required />
                                                    </div>
                                                </div>
                                                <div class="col-md-4"></div>
                                            </div>
                                        </div>
                                        <div class="tabs-form-box">
                                            <h6 class="title">Email Address </h6>
                                            <div class="row">
                                                <div class="col-md-4">
                                                    <div class="tabs-input">
                                                        <input type="email" id="freight" name="R_Email"
                                                            placeholder="Email" required />
                                                    </div>
                                                </div>
                                                <div class="col-md-4"></div>
                                            </div>
                                        </div>
                                        
                                        <div class="tj-theme-button">
                                            <button class="tj-primary-btn tabs-button" type="submit" id="submitbtn" value="submit" name="submit">
                                                Submit<i class="flaticon-right-1"></i>
                                            </button>
                                        </div>
                                    </div>
                                    </form>
                                    <div class="col-lg-4">
                                        <div class="tabs-image">
                                            <img src="assets/img2/project/tabs-2.png" alt="Image" />
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    
                     
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--=========== Contact Section End =========-->

    <!--=========== Video Section Start =========-->
    <section class="tj-video-section">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="tj-video-area text-center">
                        <div class="tj-video-popup">
                            <div class="circle pulse video-icon">
                                <a class="venobox popup-videos-button" data-autoplay="true" data-vbtype="video"
                                    href="assets/img/Agolv.mov">
                                    <i class="fa-solid fa-play"></i>
                                </a>
                            </div>
                        </div>
                        <h3 class="video-title">The Extremely Fast, most Reliable Solution.</h3>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--=========== Video Section End =========-->

    <!--=========== Counter Section Start =========-->

    <section class="tj-counter-section">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="tj-counter-area" data-bg-image="assets/images/banner/counter-shape.png">
                        <div class="counter-item d-flex align-items-center" data-sal="slide-up" data-sal-duration="800"
                            data-sal-delay="300">
                            <div class="counter-icon">
                                <i class="flaticon-box"></i>
                            </div>
                            <div class="counter-number">
                                <div class="tj-count"><span class="odometer" data-count="2000">0</span>&nbsp;+</div>
                                <span class="sub-title">Screened Couriers</span>
                            </div>
                        </div>
                        <div class="counter-item d-flex align-items-center" data-sal="slide-up" data-sal-duration="800"
                            data-sal-delay="400">
                            <div class="counter-icon">
                                <i class="flaticon-courier"></i>
                            </div>
                            <div class="counter-number">
                                <div class="tj-count"><span class="odometer" data-count="188">0</span>&nbsp;+</div>
                                <span class="sub-title">Countries and Territories <br>Reached</span>
                            </div>
                        </div>
                        <div class="counter-item d-flex align-items-center" data-sal="slide-up" data-sal-duration="800"
                            data-sal-delay="500">
                            <div class="counter-icon">
                                <i class="flaticon-worldwide"></i>
                            </div>
                            <div class="counter-number">
                                <div class="tj-count"><span class="odometer" data-count="15000">0</span>&nbsp;+</div>
                                <span class="sub-title">Agent & Customs Brokers</span>
                            </div>
                        </div>

                        <!--div class="counter-item d-flex align-items-center" data-sal="slide-up" data-sal-duration="800"
                            data-sal-delay="500">
                            <div class="counter-icon">
                                <i class="flaticon-worldwide"></i>
                            </div>
                            <div class="counter-number">
                                <div class="tj-count"><span class="odometer" data-count="4">0</span>&nbsp;+</div>
                                <span class="sub-title">Office Worldwide</span>
                            </div-->

                        </div>

                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--=========== Counter Section End =========-->

    <!--=========== Blog Section Start =========-->
    <section class="tj-blog-section-two">
        <div class="container">
            <div class="row">
                <div class="tj-section-heading text-center">
                    <span class="sub-title active-shape"> Latest News</span>
                    <h2 class="title">The Latest News & Blog</h2>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-6" data-sal="slide-left" data-sal-duration="800">
                    <div class="blog-item-three">
                        <div class="tj-blog-image">
                            <a href="blog-details.html"> <img src="assets/img2/service/service-1.jpg" alt="Image" /></a>
                        </div>
                        <div class="tj-blog-content">
                            <div class="meta-date">
                                <ul class="list-gap">
                                    <li>12</li>
                                    <li>Feb</li>
                                </ul>
                            </div>
                            <div class="blog-content-box">
                                <div class="meta-list">
                                    <ul class="list-gap">
                                        <li><i class="fa-light fa-user"></i><a href="#"> Admin</a></li>
                                        <li><i class="fa-light fa-comment"></i> <span> Comment (5)</span></li>
                                    </ul>
                                </div>
                                <div class="blog-text">
                                    <h5>
                                        <a class="title" href="blog-details.php">
                                            Navigating the Current Trends and Challenges of International Trade</a>
                                    </h5>
                                    <p>
                                        In an era where borders blur and economies intertwine, international trade serves as the lifeblood of global prosperity. However, with the world constantly evolving, new trends and challenges emerge, shaping the landscape of commerce. Join us on this journey as we explore the currents of international trade, navigate through challenges, and ride the waves of innovation.
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-6" data-sal="slide-right" data-sal-duration="800">
                    <div class="blog-item-three">
                        <div class="tj-blog-content">
                            <div class="meta-date">
                                <ul class="list-gap">
                                    <li>12</li>
                                    <li>Feb</li>
                                </ul>
                            </div>
                            <div class="blog-content-box">
                                <div class="meta-list">
                                    <ul class="list-gap">
                                        <li><i class="fa-light fa-user"></i><a href="#"> Admin</a></li>
                                        <li><i class="fa-light fa-comment"></i> <span> Comment (5)</span></li>
                                    </ul>
                                </div>
                                <div class="blog-text">
                                    <h5>
                                        <a class="title" href="blog-details.php">
                                            Navigating the Current Trends and Challenges of International Trade</a>
                                    </h5>
                                </div>
                            
                            </div>
                        </div>
                        
                     <div class="blog-item-three">
                        <div class="tj-blog-content">
                            <div class="meta-date">
                                <ul class="list-gap">
                                    <li>22</li>
                                    <li>Mar</li>
                                </ul>
                            </div>
                            <div class="blog-content-box">
                                <div class="meta-list">
                                    <ul class="list-gap">
                                        <li><i class="fa-light fa-user"></i><a href="#"> Admin</a></li>
                                        <li><i class="fa-light fa-comment"></i> <span> Comment</span></li>
                                    </ul>
                                </div>
                                <div class="blog-text">
                                    <h5>
                                        <a class="title" href="blog_2.php">
                                            Pre-Lunar New Year Rush and Red Sea Disruption Boost Asia-Europe Air Rates and Demand</a>
                                    </h5>
                                </div>
                            </div>
                            
                            
                        </div>
                        
                    </div>
                    
                     <div class="blog-item-three">
                        <div class="tj-blog-content">
                            <div class="meta-date">
                                <ul class="list-gap">
                                    <li>4</li>
                                    <li>April </li>
                                </ul>
                            </div>
                            <div class="blog-content-box">
                                <div class="meta-list">
                                    <ul class="list-gap">
                                        <li><i class="fa-light fa-user"></i><a href="#"> Admin</a></li>
                                        <li><i class="fa-light fa-comment"></i> <span> Comment</span></li>
                                    </ul>
                                </div>
                                <div class="blog-text">
                                    <h5>
                                        <a class="title" href="blog_3.php">
                                            Strategic Imperatives: Navigating Supply Chain Excellence Through 3PL Partnerships</a>
                                    </h5>
                                </div>
                            </div>
                            
                            
                        </div>
                        
                    </div>

                </div>
            </div>
        </div>
    </section>
    <!--=========== Blog Section End =========-->

    <!--=========== Footer Section Start =========-->
    <footer class="tj-footer-v2">
        <div class="container">
            <div class="row">
                <div class="col-xl-4 col-lg-3 col-md-6 col-sm-6">
                    <div class="footer-widget footer2_col_1 footer-content-info">
                        <a href="index"> <img src="assets/img/logo.png" alt="Logo" /></a>
                        <p>
                            AGOL WORLD is an international logistics company and a tenacious industry player.
                        </p>
                    </div>
                </div>
                <div class="col-xl-2 col-lg-3 col-md-6 col-sm-6">
                    <div class="footer-widget footer2_col_2 widget_nav_menu">
                        <div class="footer-title">
                            <h5 class="title">Our Services</h5>
                        </div>
                        <div class="widget-menu">
                            <ul class="list-gap">
                                <li>
                                    <a href="importer-of-record-services"> <i class="flaticon-right-chevron-1"></i> Importer On Record</a>
                                </li>
                                <li>
                                    <a href="on-board-courier-services"> <i class="flaticon-right-chevron-1"></i> On Board Courier</a>
                                </li>
                                <li>
                                    <a href="dedicated-ground-services"> <i class="flaticon-right-chevron-1"></i> Dedicated Ground </a>
                                </li>
                                <li>
                                    <a href="next-flight-out-services"> <i class="flaticon-right-chevron-1"></i> Next Flights Out</a>
                                </li>
                                <li>
                                    <a href="air-charters-services"> <i class="flaticon-right-chevron-1"></i> Air Charters</a>
                                </li>

                            </ul>
                        </div>
                    </div>
                </div>

                <div class="col-xl-3 col-lg-3 col-md-6 col-sm-6">
                    <div class="footer-widget footer2_col_4 widget_date_menu">
                        <div class="footer-title">
                            <h5 class="title">Useful Link </h5>
                        </div>
                        <div class="widget-time">
                            <ul class="list-gap">
                                <li>
                                    <a href="https://www.joc.com/"> <i class=""></i> News & Media </a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>

                <div class="col-xl-3 col-lg-3 col-md-6 col-sm-6">
                    <div class="footer-widget footer2_col_4 widget_date_menu">
                        <div class="footer-title">
                            <h5 class="title">Contact Us</h5>
                        </div>
                        <div class="widget-time">
                             <ul class="list-gap">
                                    <li>
                                       <i class="fa-solid fa-envelope"></i>
                                        <a href="time.critical@agolworld.com">time.critical@agolworld.com</a>
                                    </li>
                                     <li>
                                        <i class="flaticon flaticon-call"></i><a href="tel:+12523043851">+12523043851
                                        </a>
                                    </li>
                                    <li>
                                        <i class="flaticon flaticon-call"></i><a href="tel:+442034753632">+442034753632
                                        </a>
                                    </li>
                                    <!--li>
                                        <i class="flaticon flaticon-call"></i><a href="tel: +4980316194976">
                                            +4980316194976
                                        </a>
                                    </li-->
                                </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="copyright-bottom-two">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="footer-copyright-two">
                            <div class="copyright-target">
                                <p>
                                    Copyright © 2024 <a href="#" target="_blank"> AGOL WORLD </a> All Rights
                                    Reserved.
                                </p>
                            </div>
                            <!--div class="copyright-menu">
                                <ul class="list-gap">
                                    <li><a href="#"> Setting & privacy</a></li>
                                    <li><a href="#"> Faqs</a></li>
                                    <li><a href="contact_us"> Support</a></li>
                                </ul>
                            </div-->
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="icon-bara-d">
            <a href="https://wa.me/919730702811?text=Hi%2C%20Need%20a%20Quote" target="_blank" class="whatsapp">
                <img src="/assets/img/whatsapp.png" alt="WhatsApp" />
            </a>
        </div>
        
        <!-- start scrollUp  -->
    <div class="logiland-scroll-top progress-done">
        <svg class="progress-circle svg-content" width="100%" height="100%" viewBox="-1 -1 102 102">
            <path d="M50,1 a49,49 0 0,1 0,98 a49,49 0 0,1 0,-98" style="
                        transition: stroke-dashoffset 10ms linear 0s;
                        stroke-dasharray: 307.919px, 307.919px;
                        stroke-dashoffset: 71.1186px;
                    "></path>
        </svg>
        <div class="logiland-scroll-top-icon">
            <svg xmlns="http://www.w3.org/2000/svg" aria-hidden="true" role="img" width="1em" height="1em"
                viewBox="0 0 24 24" data-icon="mdi:arrow-up" class="iconify iconify--mdi">
                <path fill="currentColor" d="M13 20h-2V8l-5.5 5.5l-1.42-1.42L12 4.16l7.92 7.92l-1.42 1.42L13 8v12Z">
                </path>
            </svg>
        </div>
    </div>
    <!-- End scrollUp  -->
       
<script src="https://leiadmin.com/leitag.js?color=dark&lei=9845009EB9F76EF3CC25"></script>       
        
<!-- Sendinblue Conversations {literal} -->
<!--script>
    (function(d, w, c) {
        w.SibConversationsID = '63a6b2074753d226fd082276';
        w[c] = w[c] || function() {
            (w[c].q = w[c].q || []).push(arguments);
        };
        var s = d.createElement('script');
        s.async = true;
        s.src = 'https://conversations-widget.sendinblue.com/sib-conversations.js';
        if (d.head) d.head.appendChild(s);
    })(document, window, 'SibConversations');
</script-->
<!-- /Sendinblue Conversations {/literal} -->


<!--?php include "operation.php"; ?-->
<div class="go-top">
<i class="bx bx-chevrons-up"></i>
<i class="bx bx-chevrons-up"></i>
</div>

    <script src="https://kit.fontawesome.com/your-license-key.js" crossorigin="anonymous"></script>


    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

    <!-- Modernizr.JS -->
    <script src="assets/js2/modernizr-2.8.3.min.js"></script>
    <!-- jQuery.min JS -->
    <script src="assets/js2/jquery.min.js"></script>
    <!-- Bootstrap.min JS -->
    <script src="assets/js2/bootstrap.min.js"></script>
    <!-- Meanmenu JS -->
    <script src="assets/js2/meanmenu.js"></script>
    <!-- Imagesloaded JS -->
    <script src="assets/js2/imagesloaded.pkgd.min.js"></script>
    <!-- Isotope JS -->
    <script src="assets/js2/isotope.pkgd.min.js"></script>
    <!-- Magnific JS -->
    <script src="assets/js2/jquery.magnific-popup.min.js"></script>
    <!-- Swiper.min JS -->
    <script src="assets/js2/swiper.min.js"></script>
    <!-- Owl.min JS -->
    <script src="assets/js2/owl.carousel.js"></script>
    <!-- Appear JS -->
    <script src="assets/js2/jquery.appear.min.js"></script>
    <!-- Odometer JS -->
    <script src="assets/js2/odometer.min.js"></script>
    <!-- Sal JS -->
    <script src="assets/js2/sal.js"></script>
    <!-- Nice JS -->
    <script src="assets/js2/jquery.nice-select.min.js"></script>
    <!-- Main JS -->
    <script src="assets/js2/main.js"></script>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>


<script>
    async function validateForm() {
        var email = document.getElementById("emailThree").value;
        var contactno = document.getElementById("emailTwo").value;
        var weight = document.getElementById("weightOne").value;
        var height = document.getElementById("heightOne").value;
        var width = document.getElementById("width").value;
        var length = document.getElementById("lengthOne").value;

        // Regular expressions to match numeric input
        var numericRegex = /^[0-9]+$/;

        // List of blocked email domains
        var blockedDomains = ["gmail.com", "outlook.com", "aol.com", "protonmail.com", "zoho.com", "icloud.com", "gmx.com", "mail.com", "yandex.com", "hushmail.com", "tutanota.com"];

        // Check each field for numeric input
        if (!numericRegex.test(contactno) || !numericRegex.test(weight) || !numericRegex.test(height) || !numericRegex.test(width) || !numericRegex.test(length)) {
            alert("Please enter valid numeric data.");
            return false;
        }

        // Check if email domain is blocked
        var emailDomain = email.split('@')[1];
        if (blockedDomains.includes(emailDomain)) {
            alert("Sorry, emails from this domain are not allowed.");
            return false;
        }

        // Check if email domain exists
        try {
            const domainExists = await verifyEmailDomain(email);
            if (!domainExists) {
                alert("The email domain does not exist or has no mail server.");
                return false;
            }
        } catch (error) {
            console.error('Error verifying email domain:', error);
            alert("An error occurred while verifying the email domain. Please try again later.");
            return false;
        }

        // Form is valid, allow submission
        return true;
    }

    async function verifyEmailDomain(email) {
        // Extract the domain from the email address
        const domain = email.split('@')[1];

        // Query the DNS to check for MX (Mail Exchange) records
        return new Promise((resolve, reject) => {
            const dns = require('dns');
            dns.resolveMx(domain, (err, addresses) => {
                if (err) {
                    // An error occurred, domain doesn't exist or DNS error
                    console.error('DNS resolution error:', err);
                    reject(err);
                } else if (addresses && addresses.length > 0) {
                    // Domain exists, MX records found
                    resolve(true);
                } else {
                    // Domain exists, but no MX records found
                    resolve(false);
                }
            });
        });
    }
</script>




<!--script>
$(document).ready(function() {
    $(".tabs-button").click(function() {
        var form = $(this).closest('form');
        var submitBtn = $(this);
        submitBtn.attr("disabled", true);
        submitBtn.html('Please Wait');

        $.ajax({
            url: "operation.php", // Change this to your operation file
            type: "POST",
            data: form.serialize(),
            success: function(data) {
                if (data == '1') {
                    submitBtn.html('Request For A Quote <i class="flaticon-right-1"></i>');
                    submitBtn.attr("disabled", false);
                    form[0].reset();
                    $('#alertsub').html("Thank you for your enquiry! Our team will contact you soon.");
                } else {
                    $('#alertsub').html(data);
                    submitBtn.html('Request For A Quote <i class="flaticon-right-1"></i>');
                    submitBtn.attr("disabled", false);
                }
            },
            error: function(xhr, status, error) {
                console.error(xhr.responseText);
                $('#alertsub').html("An error occurred. Please try again later.");
                submitBtn.html('Request For A Quote <i class="flaticon-right-1"></i>');
                submitBtn.attr("disabled", false);
            }
        });
    });
});
</script-->



</body>
</html>