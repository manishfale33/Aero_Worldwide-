<!doctype html>
<html lang="zxx">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <!-- Favicon -->
        <link rel="apple-touch-icon" href="/assets/img/favicon.png" />
        <link rel="shortcut icon" type="image/x-icon" href="/assets/img/favicon.png" />

        <!-- Bootstrap  v5.1.3 css -->
        <link rel="stylesheet" href="/assets/css2/bootstrap.min.css" />
        <!-- Meanmenu  css -->
        <link rel="stylesheet" href="/assets/css2/meanmenu.css" />
        <!-- Sal css -->
        <link rel="stylesheet" href="/assets/css2/sal.css" />
        <!-- Magnific css -->
        <link rel="stylesheet" href="/assets/css2/magnific-popup.css" />
        <!-- Swiper Slider css -->
        <link rel="stylesheet" href="/assets/css2/swiper.min.css" />
        <!-- Carousel css file -->
        <link rel="stylesheet" href="/assets/css2/owl.carousel.css" />
        <!-- Icons css -->
        <link rel="stylesheet" href="/assets/css2/icons.css" />
        <!-- Odometer css -->
        <link rel="stylesheet" href="/assets/css2/odometer.min.css" />
        <!-- Select css -->
        <link rel="stylesheet" href="/assets/css2/nice-select.css" />
        <!-- Animate css -->
        <link rel="stylesheet" href="/assets/css2/animate.css" />
        <!-- Style css -->
        <link rel="stylesheet" href="/assets/css2/style.css" />
        <link rel="stylesheet" href="/assets/css/style.css" />
        <!-- Responsive css -->
        <link rel="stylesheet" href="/assets/css2/responsive.css" />
<link rel="icon" type="image/png" href="/assets/img/favicon.png">
<title>Our Blogs - AGOL Worldwide</title>
<meta name="description" content="AGOL Worldwide India Pvt. Ltd, Cerebrum IT Park, B1 & B2, Office 201, 2nd Floor,SNo131/1B Hissa No 1/2/3, Vadgaonsheri Pune,
MAHARASHTRA - 411014." />
 <meta name="keywords" content="AGOL Worldwide India Pvt. Ltd, AGOL Worldwide Contact, AGOL Worldwide Phone number, AGOL Worldwide address, AGOL Worldwide location.">
    <link rel="canonical" href="https://www.agolworld.com/contact_us" />
<meta name="google-site-verification" content="bYPjDNhKciLAeyyjkq_x7d89SSEzQSRNheaTzNRqCZE" />
<style>
.shipment-content {
    text-align: center;
    max-width: 1200px;
    margin: auto;
}
</style>
</head>
<body>

<div class="preloader">
<div class="lds-ripple">
<div></div>
<div></div>
</div>
</div>
 <!-- Preloader start -->
    <div id="preloader" class="preloader">
        <div class="animation-preloader">
            <div class="spinner">
                <div class="loader-icon">
                    <img src="assets/img/logo.png" alt="Agol World" />
                </div>
            </div>
            <div class="txt-loading">
                <span data-text-preloader="A" class="letters-loading">A</span>
                <span data-text-preloader="G" class="letters-loading">G</span>
                <span data-text-preloader="O" class="letters-loading">O</span>
                <span data-text-preloader="L" class="letters-loading">L</span>
                <span data-text-preloader="W" class="letters-loading">W</span>
                <span data-text-preloader="O" class="letters-loading">O</span>
                <span data-text-preloader="R" class="letters-loading">R</span>
                <span data-text-preloader="L" class="letters-loading">L</span>
                <span data-text-preloader="D" class="letters-loading">D</span>
                <!--span data-text-preloader="W" class="letters-loading">W</span>
                <span data-text-preloader="I" class="letters-loading">I</span>
                <span data-text-preloader="D" class="letters-loading">D</span>
                <span data-text-preloader="E" class="letters-loading">E</span-->

            </div>
        </div>
        <button class="tj-primary-btn">Cancel Preloader</button>
    </div>
    <!-- Preloader end -->
<!-- Offcanvas Area Start-->
    <div id="tj-overlay-bg2" class="tj-overlay-canvas"></div>
    <div class="tj-offcanvas-area">
        <div class="tj-offcanvas-header d-flex align-items-center justify-content-between">
            <div class="logo-area text-center">
                <a href="index.php"><img src="assets/img/logo.png" alt="Logo" /></a>
            </div>
            <div class="offcanvas-icon">
                <a id="canva_close" href="#">
                    <i class="fa-light fa-xmark"></i>
                </a>
            </div>
        </div>
        <!-- Canvas Mobile Menu start -->
        <nav class="right_menu_togle mobile-navbar-menu d-lg-none" id="mobile-navbar-menu"></nav>
        <p class="des d-none d-lg-block">

        </p>
        <!-- Canvas Menu end -->
        <div class="contact-info-list">
            <h4 class="offcanvas-title">Contact info</h4>
            <div class="contact-box contact-box1">
                <div class="contact-icon">
                 <i class="fa-solid fa-envelope"></i>
                </div>
                <div class="contact-link">
                    <span class="d-block"> Email us:</span>
                    <a href="time.critical@agolworld.com"> time.critical@agolworld.com</a>
                </div>
            </div>
            <div class="contact-box">
                <div class="contact-icon">
                    <i class="flaticon-telephone"></i>
                </div>
                <div class="contact-link">
                    <span class="d-block"> Call us:</span>
                    <i class="flaticon flaticon-call"></i><a href="tel:+12523043851">+12523043851
                    </a>
                </div>
            </div>
            <div class="contact-box">
                <div class="contact-icon">
                    <i class="flaticon-telephone"></i>
                </div>
                <div class="contact-link">
                    <span class="d-block"> Call us:</span>
                    <i class="flaticon flaticon-call"></i><a href="tel:+442034753632">+442034753632
                    </a>
                </div>
            </div>
            <!--div class="contact-box">
                <div class="contact-icon">
                    <i class="flaticon-telephone"></i>
                </div>
                <div class="contact-link">
                    <span class="d-block"> Call us:</span>
                    <i class="flaticon flaticon-call"></i><a href="tel: +4980316194976"> +4980316194976
                    </a>
                </div>
            </div-->
            <div class="contact-box">
                <div class="contact-icon">
                    <i class="flaticon-telephone"></i>
                </div>
                <div class="contact-link">
                    <span class="d-block"> Call us:</span>
                    <i class="flaticon flaticon-call"></i><a href="tel: +919730702811"> +919730702811
                    </a>
                </div>
            </div>
        </div>
        <div class="tj-theme-button tj-btn d-lg-none">
            <a class="tj-primary-btn" href="#"> Track Order <i class="flaticon-right-1"></i> </a>
        </div>
    </div>
    <!-- Offcanvas Area End-->

    <!-- start: Search Popup -->
    <section class="search_popup">
        <div class="container">
            <div class="row">
                <div class="col-xxl-12">
                    <div class="search_wrapper">
                        <div class="search_top d-flex justify-content-between align-items-center">
                            <div class="search_logo">
                                <a href="index.php">
                                    <img src="assets/img/logo.png" alt="logo" />
                                </a>
                            </div>
                            <div class="search_close">
                                <a class="search_close_btn" href="#"> <i class="fa-regular fa-xmark"></i></a>
                            </div>
                        </div>
                        <div class="search_form">
                            <form action="#">
                                <div class="search_input">
                                    <input class="search-input-field" type="text"
                                        placeholder="Type here to search..." />
                                    <span class="search-focus-border"></span>
                                    <a href="#"> <i class="flaticon-loupe"></i></a>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <div class="search-popup-overlay"></div>
    <!-- end: Search Popup -->

  <header class="header-section-two" id="header-sticky">
        <div class="header-topbar d-none d-lg-block">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="topbar-content-area">
                            <div class="header-content-left">
                                <ul class="list-gap">
                                    <li>
                                       <i class="fa-solid fa-envelope"></i><a
                                            href="mailto:time.critical@agolworld.com"> time.critical@agolworld.com</a>
                                    </li><a style="color: white;">24*7 Customer Service</a>&nbsp;
                                    <li>
                                        <i class="flaticon flaticon-call"></i><a href="tel:+12523043851">+12523043851
                                        </a>
                                    </li>
                                    <li>
                                        <i class="flaticon flaticon-call"></i><a href="tel:+442034753632">+442034753632
                                        </a>
                                    </li>
                                    <!--li>
                                        <i class="flaticon flaticon-call"></i><a href="tel: +4980316194976">
                                            +4980316194976
                                        </a>
                                    </li-->
                                </ul>
                            </div>
                            <div class="header-content-right d-flex align-items-center justify-content-end">
                                <div class="input-form tj-select">
                                    <a>
                                        <div class="single-footer-widget">
                                            <!-- Container for the custom translation bar -->
                                            <div id="custom_translate_element"></div>
                                        </div>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- header menu Start -->
        <div class="tj-header-menu-bottom">
            <div class="container">
                <div class="row align-items-center">
                    <div class="col-lg-12">
                        <div class="header-menu-area">
                            <!-- Logo Section Start -->
                            <div class="logo-box">
                                <a href="index"><img src="assets/img/logo.png" alt="Logo" /></a>
                            </div>
                            <!-- Logo Section End -->

                            <!-- Mainmenu Item Start -->
                            <div class="tj-main-menu d-lg-block d-none text-end" id="main-menu">
                                <ul class="main-menu">
                                    <li class="">
                                        <a class="" href="index"> Home</a>
                                    </li>
                                    <li class="">
                                        <a href="about_us"> About Us</a>
                                    </li>
                                    <li class="menu-item-has-children">
                                        <a href="service"> Services</a>
                                        <ul class="list-gap sub-menu-list">
                                            <li><a href="importer-of-record-services">Importer On Record</a></li>
                                            <li><a href="on-board-courier-services">On Board Courier</a></li>
                                            <li><a href="dedicated-ground-services">Dedicated Ground</a></li>
                                            <li><a href="next-flight-out-services">Next Flights Out</a></li>
                                            <li><a href="air-charters-services">Air Charters</a></li>
                                        </ul>
                                    </li>
                                    <li class="">
                                        <a href="industries">Industries</a>
                                    </li>
                                    <li class="">
                                        <a href="blog"> Blog</a>
                                    </li>
                                    <li class=""><a href="contact_us">Contact</a></li>
                                </ul>
                            </div>
                            <!-- Mainmenu Item End -->

                            <div class="menu-search-box d-flex align-items-center">
                                <div class="header_searce d-none d-lg-block">
                                    <button class="search-btn"><i class="flaticon-loupe"></i></button>
                                </div>
                                <div class="hambugar-icon d-none d-lg-block">
                                    <a class="canva_expander" href="#">
                                        <i class="flaticon-menu"></i>
                                    </a>
                                </div>
                                <div class="">
                                    <a>
                                        <div class="single-footer-widget">
                                            <!-- Container for the custom translation bar -->
                                            <div id="custom_translate_element"></div>
                                        </div>
                                    </a>
                                </div>
                                <div class="tj-hambagur-icon d-lg-none">
                                    <a class="canva_expander nav-menu-link menu-button" href="#">
                                        <span class="dot1"></span>
                                        <span class="dot2"></span>
                                        <span class="dot3"></span>
                                    </a>
                                </div>
                                <div class="tj-theme-button tj-btn text-end d-none d-lg-block">
                                    <a class="tj-primary-btn" href="contact.html">
                                        Track Order <i class="flaticon-right-1"></i>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- Header end End -->
                </div>
            </div>
        </div>

        <!-- header menu Start -->
    </header>
    
     <script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>

    <script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>

    <!-- Google Translate API script -->
    <script type="text/javascript"
        src="//translate.google.com/translate_a/element.js?cb=googleTranslateElementInit"></script>

    <!-- Google Translate API initialization script -->
   <script type="text/javascript">
 function googleTranslateElementInit() {
    new google.translate.TranslateElement({
        pageLanguage: 'en',
        includedLanguages: 'en,af,sq,am,ar,hy,az,eu,be,bn,bs,bg,ca,ceb,ny,zh-CN,zh-TW,co,hr,cs,da,nl,en,eo,et,tl,fi,fr,fy,gl,ka,de,el,gu,ht,ha,haw,iw,hmn,hu,is,ig,id,ga,it,ja,jw,kn,kk,km,ko,kk,ku,ky,lo,la,lv,lt,lb,mk,mg,ms,ml,mt,mi,mr,mn,my,ne,no,or,ps,fa,pl,pt,pa,ro,ru,sm,gd,sr,st,sn,sd,si,sk,sl,so,es,su,sw,sv,tg,ta,tt,te,th,tr,tk,uk,ur,ug,uz,vi,cy,xh,yi,yo,zu',
        layout: google.translate.TranslateElement.InlineLayout.SIMPLE,
        autoDisplay: false
    }, 'custom_translate_element');
}


    // Trigger the initialization script
    $(document).ready(function () {
        googleTranslateElementInit();
    });
</script>

 <!--========== breadcrumb Start ==============-->
    <section class="breadcrumb-wrapper" data-bg-image="assets/img2/banner/breadcrumb.jpg">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="breadcrumb-content">
                        <h1 class="breadcrumb-title text-center">Blog</h1>
                        <div class="breadcrumb-link">
                            <span>
                                <a href="index">
                                    <span>Home</span>
                                </a>
                            </span>
                            >
                            <span>
                                <span>Blog</span>
                            </span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--========== breadcrumb End ==============-->

    <!--========== blog details Start ==============-->
    <section class="tj-blog-details">
        <div class="container">
            <div class="row">
                <div class="col-lg-8">
                    <div class="page-details-wrapper">
                        <div class="tj-blog-item-three">
                            <div class="tj-blog-image">
                                <a href="blog-details">
                                    <img src="assets/img2/blog/(15).png" alt="Blog" /></a>
                            </div>
                            <div class="active-text">
                                <a href="blog-details"> Logistics</a>
                            </div>
                            <div class="blog-content-area">
                                <div class="blog-header">
                                    <h3>
                                        <a class="title-link" href="">
                                            Pre-Lunar New Year Rush and Red Sea Disruption Boost Asia-Europe Air Rates and Demand</a>
                                    </h3>
                                </div>
                                <div class="blog-meta">
                                    <div class="meta-list">
                                        <ul class="list-gap">
                                            <li><i class="fa-light fa-user"></i> <a href="#"> Admin</a></li>
                                            <li><i class="flaticon-calendar"></i> <span> March 22, 2024</span></li>
                                            <li><i class="fa-light fa-comment"></i> <span> Comment </span></li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="row align-items-center">
                            <div class="col-lg-5 col-md-6">
                                <div class="">
                                    <img src="assets/img2/blog/(13).png" alt="Blog" />
                                </div>
                            </div>
                            <div class="col-lg-5 col-md-6">
                                
                                <p>
                                   <h4 class="title">Pre-Lunar New Year Rush:</h4>  is a crucial period for factories in Asia, marked by a flurry of production
    and shipment activities as businesses strive to meet deadlines before the Lunar New Year. Concurrently, the <em>Red
      Sea disruption</em> has significantly impacted supply chains, leading to delayed or disrupted shipments via sea
    freight channels. In light of these challenges, air cargo has emerged as a key player in mitigating the logistical
    hurdles presented by these events.

                                   
                            </div>
                        </div>
                        <div class="details-video-content">
                            <h4 class="title"></h4>
                            <p>
                                
                                <h4 class="title">Understanding the Pre-Lunar New Year Rush</h4> The Pre-Lunar New Year rush holds significant importance for businesses in Asia, particularly in meeting critical
    deadlines before the factory closures associated with the Lunar New Year. This period prompts a surge in production
    and shipment activities as companies strive to fulfill orders and deliver goods before the holiday hiatus.</p>
  <p>Here are some key points to understand about the Pre-Lunar New Year rush:</p>
  <ol>
    <li><strong>Importance of Meeting Deadlines:</strong> The significance of meeting deadlines before the Lunar New
      Year is crucial for businesses to maintain supply chain efficiency and customer satisfaction.</li>
    <li><strong>Increased Production and Shipping:</strong> Asian factories experience heightened production levels and
      intensified shipping operations to accommodate the increased demand and ensure timely delivery of goods.</li>
    <li><strong>Case Study: AGOL Worldwide USA:</strong> AGOL Worldwide USA plays a pivotal role in managing
      time-critical shipments during this period, leveraging its expertise in coordinating air cargo services to meet
      strict timelines and navigate the complexities of the Pre-Lunar New Year rush.</li>
  </ol>
                                
                                <h4 class="title">The Impact of the Red Sea Disruption on Supply Chains</h4> <p>The disruption in the Red Sea has had far-reaching consequences for ocean networks, particularly in the realm of
    supply chains. As a result of this disruption, there have been numerous delayed or disrupted shipments via sea
    freight channels. This has led to logistical challenges and increased pressure on alternative transportation modes
    such as air cargo to mitigate these disruptions effectively.</p>
  <p>AGOL Worldwide India faced significant challenges amidst the Red Sea disruption. The company had to reevaluate its
    supply chain strategies and implement alternative routes and modes of transportation to ensure the timely delivery
    of goods to their destinations. By leveraging air cargo and exploring different shipping lanes, AGOL Worldwide India
    was able to navigate through the challenges posed by the Red Sea disruption and maintain a reliable supply chain for
    its customers.</p>
  <p>This disruption serves as a poignant example of the susceptibility of supply chains to external factors beyond
    traditional control. It underscores the importance of agility and adaptability within supply chain management, as
    well as the need for diversified transportation options to mitigate the impact of such disruptions on global trade
    and commerce.</p>

                                <h4 class="title">The Role of Air Cargo in Overcoming Challenges</h4> While the current environment presents challenges for both carriers and shippers, it also presents opportunities for industry stakeholders. Carriers stand to benefit from higher rates and increased demand, although they must navigate capacity constraints and operational challenges effectively. For shippers, the focus is on securing reliable transportation solutions and optimizing supply chain strategies to mitigate risks and maintain business continuity.

                              <h4 class="title">Looking Ahead:</h4>  <p>During periods of supply chain disruption, the logistics industry often turns to air cargo as a solution for
    mitigating challenges. This shift towards air transport is driven by several factors:</p>
  <h4>1. <strong>Speed and Time Sensitivity</strong></h4>
  <p>Air cargo offers unparalleled speed, making it the preferred choice for time-sensitive goods. With shorter transit
    times compared to ocean freight, air transport ensures that shipments reach their destination quickly, even amidst
    disruptions in other modes of transportation.</p>
  <h4>2. <strong>Reliability and Flexibility</strong></h4>
  <p>Air transport provides a higher level of reliability and flexibility compared to other modes of shipping. Airlines
    operate on fixed schedules and have fewer variables that can affect transit times, such as weather conditions or
    congested ports. This reliability allows businesses to better plan their supply chain operations and meet tight
    deadlines.</p>
  <h4>3. <strong>Mitigating Disruptions</strong></h4>
  <p>When disruptions occur, such as the Red Sea disruption or the Pre-Lunar New Year rush, switching to air cargo helps
    overcome challenges posed by delayed or disrupted shipments via sea freight channels. By leveraging air transport,
    businesses can ensure that their goods are delivered on time, minimizing the impact of disruptions on their supply
    chains.</p>
  <p>The increase in air rates and demand during these challenging periods is a direct result of the industry's reliance
    on air cargo to overcome supply chain disruptions. As more businesses recognize the benefits of using air transport,
    there is a surge in demand for available capacity, leading to higher rates.</p>
    
    
    
     <h4 class="title">Examining the Surge in Asia-Europe Air Rates</h4>
  <p>The surge in Asia-Europe air rates has been influenced by various factors, contributing to a notable increase in
    air freight prices on this trade lane. Some key points to consider include:</p>
  <h4><strong>1. Capacity Constraints</strong></h4>
  <p>Limited air cargo capacity due to reduced passenger flights and grounded aircraft have led to a shortage of space
    for freight, driving up rates.</p>
  <h4><strong>2. High Demand</strong></h4>
  <p>The heightened need for time-sensitive shipments has resulted in increased demand for air cargo services from Asia
    to Europe, further amplifying the competition for limited space.</p>
  <h4><strong>3. Seasonal Trends</strong></h4>
  <p>The pre-Lunar New Year rush has intensified the urgency for air shipments out of Asia, creating a surge in demand
    and subsequently impacting rates.</p>
  <p>When comparing current air rates with historical data, it becomes evident that the spike in prices is unprecedented
    and directly linked to the unique confluence of disruptions, high demand, and capacity constraints. The comparison
    underscores the significance of these current challenges in driving air rates to exceptional levels, setting a new
    standard for pricing dynamics on the Asia-Europe trade lane.</p>
  <h4 class="title">Meeting the Increased Demand for Air Cargo Services</h4>
  <p>The heightened demand for air cargo capacity from Asia to Europe is primarily driven by the need for timely
    shipments before the Lunar New Year and the disruptions in sea freight networks, such as those caused by the Red Sea
    crisis. This increased demand has significant implications for logistics companies and airlines:</p>
  <h4><strong>Drivers behind the heightened need for air cargo capacity from Asia to Europe:</strong></h4>
  <ol>
    <li>Urgency to meet pre-Lunar New Year deadlines</li>
    <li>Compensating for disrupted sea freight routes</li>
    <li>Ensuring timely delivery of time-sensitive goods</li>
  </ol>
  <h4><strong>Impact on logistics companies and airlines:</strong></h4>
  <ul>
    <li>Strain on available air cargo capacity</li>
    <li>Adjustment of schedules and routes to accommodate increased demand</li>
    <li>Potential revenue opportunities for airlines</li>
  </ul>
  <p>AGOL Worldwide UK has implemented strategic measures to manage the surge in air cargo demand during the Pre-Lunar
    New Year rush and Red Sea disruption. By optimizing route planning, collaborating closely with partner airlines, and
    leveraging advanced cargo management systems, AGOL Worldwide UK has been able to effectively address the challenges
    posed by the increased demand for air cargo services.
  </p>
  <h4 class ="title">Conclusion</h4>
  <p>Efficient logistics solutions are crucial for managing time-critical shipments during the Pre-Lunar New Year rush
    and Red Sea disruption. The combination of these two factors has significantly impacted supply chains, leading to a
    surge in Asia-Europe air rates and demand for air cargo services.</p>
  <p>To navigate through these challenges, it is essential for businesses to:</p>
  <ol>
    <li>Plan ahead: Anticipate the Pre-Lunar New Year rush and allocate resources accordingly to meet deadlines.</li>
    <li>Embrace air transport: Utilize air cargo for time-sensitive goods to mitigate delays caused by disrupted ocean
      networks.</li>
    <li>Partner with experienced logistics providers: Collaborate with companies like AGOL Worldwide that have a track
      record of successfully managing shipments during these critical periods.</li>
    <li>Stay updated on market trends: Monitor changes in air rates and availability to make informed decisions about
      shipping options.</li>
  </ol>
  <p>By implementing these strategies, companies can effectively address the increased demand and ensure the timely
    delivery of goods between Asia and Europe.</p>
                            </p>
                            <div class="row">
                                <div class="">
                                    <div class="blog-image">
                                        <img src="assets/img2/blog/blog11.jpg" alt="Image" />
                                    </div>
                                </div>
                                <!--div class="col-lg-6 col-md-6">
                                    <div class="blog-image">
                                        <img src="assets/img2/blog/blog14.jpg" alt="Image" />
                                    </div>
                                </div-->
                            </div>
                        </div>
                        <div class="details-tags-box">
                            <div class="tags-link">
                                <span> Tags</span>
                                <a href="#">Transport</a>
                                <a href="#">Delivery</a>
                                <a href="#">Logistics</a>
                            </div>
                        </div>
                       
                        <div class="row">
                            <div class="form-title">
                                <h4 class="details_title">Leave a Reply</h4>
                            </div>
                            <div class="col-lg-6">
                                <div class="details-input">
                                    <input type="text" id="name" name="name" placeholder="Your Name" required="" />
                                </div>
                            </div>
                            <div class="col-lg-6">
                                <div class="details-input">
                                    <input type="text" id="emailAdd" name="name" placeholder="Email Address"
                                        required="" />
                                </div>
                            </div>
                            <div class="col-lg-12">
                                <div class="details-input">
                                    <input type="text" id="site" name="name" placeholder="Email Address" required="" />
                                </div>
                            </div>
                            <div class="col-lg-12">
                                <div class="details-input">
                                    <textarea name="massage" class="form-control" cols="30" rows="10"
                                        placeholder="Comment"></textarea>
                                </div>
                            </div>
                            <div class="col-lg-12">
                                <div class="tj-theme-button">
                                    <button class="tj-primary-btn submit-btn" type="submit" value="submit">
                                        Post Comment <i class="fa-light fa-arrow-right"></i>
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4">
                    <div class="details-sidebar-inner">
                        <div class="tj-sidebar-widget sidebar-search">
                            <form action="#">
                                <input type="text" class="form-control" name="search" id="searchOne"
                                    placeholder="Search" />
                                <i class="flaticon-loupe"></i>
                            </form>
                        </div>
                        <div class="tj-sidebar-widget sidebar-post">
                            <h5 class="details_title">Popular Post</h5>
                            <div class="tj-post-content">
                                <div class="tj-auother-img">
                                    <a href="blog-details.html">
                                        <img src="assets/img2/service/service-15.jpg" alt="Blog" /></a>
                                </div>
                                <div class="tj-details-text">
                                    <div class="details-meta">
                                        <ul class="list-gap">
                                            <li><i class="flaticon-calendar"></i> Feb 18</li>
                                            <li><i class="fa-light fa-comment"></i> </li>
                                        </ul>
                                    </div>
                                    <div class="tj-details-header">
                                        <h6>
                                            <a href="blog-details">This Place Really Place For</a>
                                        </h6>
                                    </div>
                                </div>
                            </div>
                           
                        </div>
                        <div class="tj-sidebar-widget sidebar-catagory">
                            <h5 class="details_title">All Catagory</h5>
                            <ul class="list-gap">
                                <li>
                                    <a href="#">Introductions
                                        <span> </span>
                                    </a>
                                </li>
                                <li>
                                    <a href="#">Engineering
                                        <span> </span>
                                    </a>
                                </li>
                                <li>
                                    <a href="#">Transport
                                        <span> </span>
                                    </a>
                                </li>
                                <li>
                                    <a href="#">Logistics
                                        <span> </span>
                                    </a>
                                </li>
                                <li>
                                    <a href="#">Business
                                        <span> </span>
                                    </a>
                                </li>
                                <li>
                                    <a href="#">Work Permits
                                        <span> </span>
                                    </a>
                                </li>
                            </ul>
                        </div>
                        <div class="tj-sidebar-widget sidebar-tags">
                            <h5 class="details_title">Popular Tags</h5>
                            <div class="tagcloud">
                                <a href="#"> Business</a>
                                <a href="#"> Career</a>
                                <a href="#"> Logistics</a>
                                <a href="#"> Delivery</a>
                                <a href="#"> Consulting</a>
                                <a href="#"> Travel</a>
                                <a href="#">Education</a>
                                <a href="#">America</a>
                                <a href="#">Maintenance</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--========== blog details End ==============-->

    <!--=========== Footer Section Start =========-->
    <footer class="tj-footer-area">
        <div class="container">
            <div class="row">
                <div class="col-xl-4 col-lg-3 col-md-6 col-sm-6">
                    <div class="footer-widget footer1_col_1 footer-content-info"
                        data-bg-image="assets/img2/banner/footer-shape.png">
                        <a href="index.html"> <img src="assets/img/logo.png" alt="Logo" /></a>
                        <p>
                            AGOL WORLD is an international logistics company and a tenacious industry player.
                        </p>
                    </div>
                </div>
                <div class="col-xl-2 col-lg-3 col-md-6 col-sm-6">
                    <div class="footer-widget footer1_col_2 widget_nav_menu">
                        <div class="footer-title">
                            <h5 class="title">Our Services</h5>
                        </div>
                        <div class="widget-menu">
                            <ul>
                                <li>
                                    <a href="importer-of-record-services"> <i class="flaticon-plus"></i> Importer Of Record</a>
                                </li>
                                <li>
                                    <a href="on-board-courier-services"> <i class="flaticon-plus"></i> On Board Courier</a>
                                </li>
                                <li>
                                    <a href="dedicated-ground-services"> <i class="flaticon-plus"></i> Dedicated Ground </a>
                                </li>
                                <li>
                                    <a href="next-flight-out-services"> <i class="flaticon-plus"></i> Next Flight Out</a>
                                </li>
                                <li>
                                    <a href="air-charters-services"> <i class="flaticon-plus"></i> Air Charters</a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
                <div class="col-xl-3 col-lg-3 col-md-6 col-sm-6">
                    <div class="footer-widget footer1_col_3 widget_nav_menu">
                        <div class="footer-title">
                            <h5 class="title">Useful Links</h5>
                        </div>
                        <div class="widget-menu">
                            <ul>
                                <li>
                                    <a href="#"> <i class="flaticon-plus"></i> News & Media </a>
                                </li>
                                <!--li>
                                        <a href="#"> <i class="flaticon-plus"></i> Sustainability</a>
                                    </li>
                                    <li>
                                        <a href="#"> <i class="flaticon-plus"></i> About Expertise </a>
                                    </li>
                                    <li>
                                        <a href="#"> <i class="flaticon-plus"></i> Case Studies</a>
                                    </li>
                                    <li>
                                        <a href="#"> <i class="flaticon-plus"></i> Our Team </a>
                                    </li-->
                                <li>
                                    <a href="contacts_us"> <i class="flaticon-plus"></i> Contacts</a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
                <div class="col-xl-3 col-lg-3 col-md-6 col-sm-6">
                    <div class="footer-widget footer1_col_4 footer-contact-info">
                        <div class="footer-title">
                            <h5 class="title">Contact Info</h5>
                        </div>
                        <div class="widget-contact">
                            <div class="contact-list">
                                <ul class="list-gap">
                                    <li>
                                        <i class="fa-solid fa-envelope"></i>
                                        <a href="time.critical@agolworld.com">time.critical@agolworld.com</a>
                                    </li>
                                     <li>
                                        <i class="flaticon flaticon-call"></i><a href="tel:+12523043851">+12523043851
                                        </a>
                                    </li>
                                    <li>
                                        <i class="flaticon flaticon-call"></i><a href="tel:+442034753632">+442034753632
                                        </a>
                                    </li>
                                    <!--li>
                                        <i class="flaticon flaticon-call"></i><a href="tel: +4980316194976">
                                            +4980316194976
                                        </a>
                                    </li-->
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="copyright-bottom">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="footer-copyright-area">
                            <div class="copyright-target">
                                <p>
                                    Copyright © 2024 <a href="#" target="_blank"> AGOL WORLD </a> All Rights
                                    Reserved.
                                </p>
                            </div>
                            <!--div class="copyright-menu">
                                <ul class="list-gap">
                                    <li><a href="#"> Setting & privacy</a></li>
                                    <li><a href="#"> Faqs</a></li>
                                    <li><a href="contact_us"> Support</a></li>
                                </ul>
                            </div-->
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </footer>
    <!--=========== Footer Section End =========-->
     <div class="icon-bara-d">
            <a href="https://wa.me/919730702811?text=Hi%2C%20Need%20a%20Quote" target="_blank" class="whatsapp">
                <img src="/assets/img/whatsapp.png" alt="WhatsApp" />
            </a>
        </div>
        
<script src="https://leiadmin.com/leitag.js?color=dark&lei=9845009EB9F76EF3CC25"></script>

<!-- Sendinblue Conversations {literal} -->
<!--script>
    (function(d, w, c) {
        w.SibConversationsID = '63a6b2074753d226fd082276';
        w[c] = w[c] || function() {
            (w[c].q = w[c].q || []).push(arguments);
        };
        var s = d.createElement('script');
        s.async = true;
        s.src = 'https://conversations-widget.sendinblue.com/sib-conversations.js';
        if (d.head) d.head.appendChild(s);
    })(document, window, 'SibConversations');
</script-->
<!-- /Sendinblue Conversations {/literal} -->
<div class="go-top">
<i class="bx bx-chevrons-up"></i>
<i class="bx bx-chevrons-up"></i>
</div>
 <!-- Modernizr.JS -->
        <script src="assets/js2/modernizr-2.8.3.min.js"></script>
        <!-- jQuery.min JS -->
        <script src="assets/js2/jquery.min.js"></script>
        <!-- Bootstrap.min JS -->
        <script src="assets/js2/bootstrap.min.js"></script>
        <!-- Meanmenu JS -->
        <script src="assets/js2/meanmenu.js"></script>
        <!-- Imagesloaded JS -->
        <script src="assets/js2/imagesloaded.pkgd.min.js"></script>
        <!-- Isotope JS -->
        <script src="assets/js2/isotope.pkgd.min.js"></script>
        <!-- Magnific JS -->
        <script src="assets/js2/jquery.magnific-popup.min.js"></script>
        <!-- Swiper.min JS -->
        <script src="assets/js2/swiper.min.js"></script>
        <!-- Owl.min JS -->
        <script src="assets/js2/owl.carousel.js"></script>
        <!-- Appear JS -->
        <script src="assets/js2/jquery.appear.min.js"></script>
        <!-- Odometer JS -->
        <script src="assets/js2/odometer.min.js"></script>
        <!-- Sal JS -->
        <script src="assets/js2/sal.js"></script>
        <!-- Nice JS -->
        <script src="assets/js2/jquery.nice-select.min.js"></script>
        <!-- Main JS -->
        <script src="assets/js2/main.js"></script>
        
        
<script>
$("#contact-form").on('submit',(function() {
    $("#submitbtn").attr("disabled", true);
    $('#submitbtn').val('Please Wait');
    $.ajax({
    url: "operation.php",
    type: "POST",
    data:  new FormData(this),contentType: false,cache: false,processData:false,success: function(data)
            {
                if(data=='1')
                {
                $('#submitbtn').val('Submit');
                $("#submitbtn").attr("disabled", false);
                $("#contact-form")[0].reset();
				  $('#alertsub').html("Thankyou For Enquiry Our Contact Team will contact you soon");
                }
                else
                {
                    $('#alertsub').html(data);
                    $('#submitbtn').val('Submit');
                    $("#submitbtn").attr("disabled", false);
                }
            }       
     });
     return false; 
    }));
</script>
</body>
</html>
